import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Camera, 
  History, 
  Settings, 
  Volume2, 
  Globe, 
  User, 
  ArrowRight, 
  Trash2, 
  CheckCircle2, 
  Mic, 
  Languages, 
  Heart, 
  Home,
  LogOut,
  ChevronRight,
  Share2
} from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import confetti from 'canvas-confetti';

// --- Utility ---
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// --- Types ---
type Language = 'ar' | 'en' | 'fr' | 'es';
type Dialect = 'ar-EG' | 'ar-SA' | 'ar-XA';

interface UserProfile {
  name: string;
  age: string;
  email: string;
  phone: string;
}

interface SignItem {
  id: string;
  emoji: string;
  translations: Record<Language, string>;
  category: 'common' | 'family' | 'emotions' | 'actions';
}

// --- Constants ---
const SIGNS: SignItem[] = [
  { id: '1', emoji: '👋', translations: { ar: 'مرحباً', en: 'Hello', fr: 'Bonjour', es: 'Hola' }, category: 'common' },
  { id: '2', emoji: '🙏', translations: { ar: 'شكراً', en: 'Thank you', fr: 'Merci', es: 'Gracias' }, category: 'common' },
  { id: '3', emoji: '❤️', translations: { ar: 'أحبك', en: 'I love you', fr: 'Je t\'aime', es: 'Te amo' }, category: 'emotions' },
  { id: '4', emoji: '🤝', translations: { ar: 'صديق', en: 'Friend', fr: 'Ami', es: 'Amigo' }, category: 'common' },
  { id: '5', emoji: '🏠', translations: { ar: 'منزل', en: 'Home', fr: 'Maison', es: 'Casa' }, category: 'common' },
  { id: '6', emoji: '👨', translations: { ar: 'أب', en: 'Father', fr: 'Père', es: 'Padre' }, category: 'family' },
  { id: '7', emoji: '👩', translations: { ar: 'أم', en: 'Mother', fr: 'Mère', es: 'Madre' }, category: 'family' },
  { id: '8', emoji: '💧', translations: { ar: 'ماء', en: 'Water', fr: 'Eau', es: 'Agua' }, category: 'common' },
  { id: '9', emoji: '🍎', translations: { ar: 'طعام', en: 'Food', fr: 'Nourriture', es: 'Comida' }, category: 'common' },
  { id: '10', emoji: '✅', translations: { ar: 'نعم', en: 'Yes', fr: 'Oui', es: 'Sí' }, category: 'common' },
  { id: '11', emoji: '❌', translations: { ar: 'لا', en: 'No', fr: 'Non', es: 'No' }, category: 'common' },
  { id: '12', emoji: '❓', translations: { ar: 'كيف حالك؟', en: 'How are you?', fr: 'Comment ça va?', es: '¿Cómo estás?' }, category: 'common' },
  { id: '13', emoji: '😴', translations: { ar: 'نوم', en: 'Sleep', fr: 'Dormir', es: 'Dormir' }, category: 'actions' },
  { id: '14', emoji: '🚶', translations: { ar: 'يمشي', en: 'Walk', fr: 'Marcher', es: 'Caminar' }, category: 'actions' },
  { id: '15', emoji: '🏃', translations: { ar: 'يجري', en: 'Run', fr: 'Courir', es: 'Correr' }, category: 'actions' },
  { id: '16', emoji: '🆘', translations: { ar: 'مساعدة', en: 'Help', fr: 'Aide', es: 'Ayuda' }, category: 'common' },
  { id: '17', emoji: '😊', translations: { ar: 'سعيد', en: 'Happy', fr: 'Heureux', es: 'Feliz' }, category: 'emotions' },
  { id: '18', emoji: '😢', translations: { ar: 'حزين', en: 'Sad', fr: 'Triste', es: 'Triste' }, category: 'emotions' },
  { id: '19', emoji: '😡', translations: { ar: 'غاضب', en: 'Angry', fr: 'En colère', es: 'Enojado' }, category: 'emotions' },
  { id: '20', emoji: '🏥', translations: { ar: 'مستشفى', en: 'Hospital', fr: 'Hôpital', es: 'Hospital' }, category: 'common' },
];

// --- Components ---

const GlassCard = ({ children, className }: { children: React.ReactNode; className?: string }) => (
  <div className={cn("bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl overflow-hidden shadow-2xl", className)}>
    {children}
  </div>
);

const AnimatedBackground = () => (
  <div className="fixed inset-0 -z-10 overflow-hidden">
    <div className="absolute inset-0 bg-[#0f172a]" />
    <motion.div 
      animate={{ 
        scale: [1, 1.2, 1],
        rotate: [0, 90, 0],
        x: [0, 100, 0],
        y: [0, 50, 0]
      }}
      transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
      className="absolute -top-1/2 -left-1/2 w-full h-full bg-indigo-500/20 blur-[120px] rounded-full"
    />
    <motion.div 
      animate={{ 
        scale: [1, 1.5, 1],
        rotate: [0, -90, 0],
        x: [0, -100, 0],
        y: [0, -50, 0]
      }}
      transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
      className="absolute -bottom-1/2 -right-1/2 w-full h-full bg-emerald-500/20 blur-[120px] rounded-full"
    />
  </div>
);

export default function App() {
  const [user, setUser] = useState<UserProfile | null>(() => {
    const saved = localStorage.getItem('eshara_user');
    return saved ? JSON.parse(saved) : null;
  });
  const [lang, setLang] = useState<Language>('ar');
  const [dialect, setDialect] = useState<Dialect>('ar-EG');
  const [speechRate, setSpeechRate] = useState(1);
  const [history, setHistory] = useState<SignItem[]>(() => {
    const saved = localStorage.getItem('eshara_history');
    return saved ? JSON.parse(saved) : [];
  });
  const [activeTab, setActiveTab] = useState<'home' | 'camera' | 'history' | 'settings'>('home');
  const [isCameraActive, setIsCameraActive] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  const isRTL = lang === 'ar';

  useEffect(() => {
    if (user) localStorage.setItem('eshara_user', JSON.stringify(user));
  }, [user]);

  useEffect(() => {
    localStorage.setItem('eshara_history', JSON.stringify(history));
  }, [history]);

  const speak = (text: string) => {
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = lang === 'ar' ? dialect : lang;
    utterance.rate = speechRate;
    window.speechSynthesis.speak(utterance);
  };

  const handleSignClick = (sign: SignItem) => {
    speak(sign.translations[lang]);
    setHistory(prev => [sign, ...prev.slice(0, 49)]);
    confetti({
      particleCount: 30,
      spread: 60,
      origin: { y: 0.8 },
      colors: ['#6366f1', '#10b981', '#f59e0b']
    });
  };

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setIsCameraActive(true);
      }
    } catch (err) {
      console.error("Camera access denied", err);
    }
  };

  const stopCamera = () => {
    if (videoRef.current?.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      setIsCameraActive(false);
    }
  };

  if (!user) {
    return <Onboarding onComplete={setUser} isRTL={isRTL} />;
  }

  return (
    <div className={cn("min-h-screen text-white font-sans selection:bg-indigo-500/30", isRTL ? "rtl" : "ltr")}>
      <AnimatedBackground />
      
      {/* Header */}
      <header className="fixed top-0 inset-x-0 z-50 px-6 py-4 flex items-center justify-between bg-black/20 backdrop-blur-lg border-b border-white/10">
        <div className="flex items-center gap-3">
          <motion.div 
            animate={{ rotate: 360 }}
            transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
            className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-emerald-500 flex items-center justify-center shadow-lg shadow-indigo-500/20"
          >
            <Languages className="text-white w-6 h-6" />
          </motion.div>
          <div>
            <h1 className="text-lg font-bold tracking-tight">EsharaTalk EG</h1>
            <p className="text-[10px] uppercase tracking-widest opacity-50 font-semibold">Sign Language AI</p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <select 
            value={lang}
            onChange={(e) => setLang(e.target.value as Language)}
            className="bg-white/10 border border-white/20 rounded-full px-3 py-1 text-xs outline-none hover:bg-white/20 transition-colors"
          >
            <option value="ar" className="bg-slate-900">العربية</option>
            <option value="en" className="bg-slate-900">English</option>
            <option value="fr" className="bg-slate-900">Français</option>
            <option value="es" className="bg-slate-900">Español</option>
          </select>
          <button 
            onClick={() => {
              localStorage.removeItem('eshara_user');
              setUser(null);
            }}
            className="p-2 rounded-full hover:bg-white/10 transition-colors"
          >
            <LogOut className="w-5 h-5 opacity-60" />
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="pt-24 pb-32 px-6 max-w-2xl mx-auto">
        <AnimatePresence mode="wait">
          {activeTab === 'home' && (
            <motion.div 
              key="home"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8"
            >
              <div className="space-y-2">
                <h2 className="text-3xl font-bold">
                  {lang === 'ar' ? `مرحباً، ${user.name}` : `Hello, ${user.name}`}
                </h2>
                <p className="opacity-60 text-sm">
                  {lang === 'ar' ? 'اختر إشارة لترجمتها إلى صوت' : 'Choose a sign to translate to voice'}
                </p>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                {SIGNS.map((sign) => (
                  <motion.button
                    key={sign.id}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => handleSignClick(sign)}
                    className="group relative"
                  >
                    <GlassCard className="p-6 flex flex-col items-center gap-3 hover:bg-white/20 transition-all duration-300">
                      <span className="text-4xl group-hover:scale-125 transition-transform duration-500">{sign.emoji}</span>
                      <span className="text-sm font-medium opacity-80">{sign.translations[lang]}</span>
                      <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <Volume2 className="w-4 h-4 text-indigo-400" />
                      </div>
                    </GlassCard>
                  </motion.button>
                ))}
              </div>
            </motion.div>
          )}

          {activeTab === 'camera' && (
            <motion.div 
              key="camera"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="space-y-6"
            >
              <GlassCard className="aspect-[4/3] relative flex items-center justify-center bg-black/40">
                {!isCameraActive ? (
                  <div className="text-center space-y-4 p-8">
                    <div className="w-20 h-20 bg-indigo-500/20 rounded-full flex items-center justify-center mx-auto">
                      <Camera className="w-10 h-10 text-indigo-400" />
                    </div>
                    <h3 className="text-xl font-bold">{lang === 'ar' ? 'تفعيل الكاميرا' : 'Activate Camera'}</h3>
                    <p className="text-sm opacity-60">
                      {lang === 'ar' ? 'استخدم الكاميرا للتعرف على الإشارات في الوقت الفعلي' : 'Use camera for real-time sign recognition'}
                    </p>
                    <button 
                      onClick={startCamera}
                      className="bg-indigo-600 hover:bg-indigo-500 text-white px-8 py-3 rounded-2xl font-bold transition-all shadow-xl shadow-indigo-500/20"
                    >
                      {lang === 'ar' ? 'ابدأ الآن' : 'Start Now'}
                    </button>
                  </div>
                ) : (
                  <>
                    <video 
                      ref={videoRef} 
                      autoPlay 
                      playsInline 
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 border-2 border-indigo-500/50 m-8 rounded-2xl pointer-events-none">
                      <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-indigo-500 rounded-tl-lg" />
                      <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-indigo-500 rounded-tr-lg" />
                      <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-indigo-500 rounded-bl-lg" />
                      <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-indigo-500 rounded-br-lg" />
                    </div>
                    <div className="absolute bottom-6 inset-x-0 flex justify-center gap-4">
                      <button 
                        onClick={stopCamera}
                        className="bg-red-500/80 backdrop-blur-md p-4 rounded-full hover:bg-red-500 transition-colors"
                      >
                        <Trash2 className="w-6 h-6" />
                      </button>
                    </div>
                  </>
                )}
              </GlassCard>
              
              <div className="bg-indigo-500/10 border border-indigo-500/20 rounded-2xl p-4 flex items-center gap-4">
                <div className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse" />
                <p className="text-sm font-medium text-indigo-300">
                  {lang === 'ar' ? 'الذكاء الاصطناعي جاهز للتحليل...' : 'AI is ready for analysis...'}
                </p>
              </div>
            </motion.div>
          )}

          {activeTab === 'history' && (
            <motion.div 
              key="history"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold">{lang === 'ar' ? 'السجل' : 'History'}</h2>
                <button 
                  onClick={() => setHistory([])}
                  className="text-xs text-red-400 hover:text-red-300 flex items-center gap-1"
                >
                  <Trash2 className="w-4 h-4" />
                  {lang === 'ar' ? 'مسح الكل' : 'Clear All'}
                </button>
              </div>

              {history.length === 0 ? (
                <div className="text-center py-20 opacity-40">
                  <History className="w-12 h-12 mx-auto mb-4" />
                  <p>{lang === 'ar' ? 'لا يوجد سجل بعد' : 'No history yet'}</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {history.map((item, idx) => (
                    <motion.div 
                      key={`${item.id}-${idx}`}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.05 }}
                    >
                      <GlassCard className="p-4 flex items-center justify-between group">
                        <div className="flex items-center gap-4">
                          <span className="text-2xl">{item.emoji}</span>
                          <div>
                            <p className="font-bold">{item.translations[lang]}</p>
                            <p className="text-[10px] opacity-40 uppercase tracking-tighter">
                              {new Date().toLocaleTimeString()}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <button 
                            onClick={() => speak(item.translations[lang])}
                            className="p-2 rounded-full hover:bg-white/10 transition-colors"
                          >
                            <Volume2 className="w-4 h-4" />
                          </button>
                          <button className="p-2 rounded-full hover:bg-white/10 transition-colors">
                            <Share2 className="w-4 h-4" />
                          </button>
                        </div>
                      </GlassCard>
                    </motion.div>
                  ))}
                </div>
              )}
            </motion.div>
          )}

          {activeTab === 'settings' && (
            <motion.div 
              key="settings"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8"
            >
              <h2 className="text-2xl font-bold">{lang === 'ar' ? 'الإعدادات' : 'Settings'}</h2>
              
              <div className="space-y-6">
                <section className="space-y-4">
                  <h3 className="text-sm font-bold uppercase tracking-widest opacity-40">{lang === 'ar' ? 'الصوت' : 'Voice'}</h3>
                  <GlassCard className="p-6 space-y-6">
                    <div className="space-y-2">
                      <label className="text-sm font-medium">{lang === 'ar' ? 'اللهجة' : 'Dialect'}</label>
                      <div className="grid grid-cols-1 gap-2">
                        {[
                          { id: 'ar-EG', label: lang === 'ar' ? 'المصرية' : 'Egyptian' },
                          { id: 'ar-SA', label: lang === 'ar' ? 'السعودية' : 'Saudi' },
                          { id: 'ar-XA', label: lang === 'ar' ? 'العربية العامة' : 'General Arabic' },
                        ].map((d) => (
                          <button
                            key={d.id}
                            onClick={() => setDialect(d.id as Dialect)}
                            className={cn(
                              "px-4 py-3 rounded-xl text-sm font-medium transition-all text-left flex items-center justify-between",
                              dialect === d.id ? "bg-indigo-600 text-white" : "bg-white/5 hover:bg-white/10"
                            )}
                          >
                            {d.label}
                            {dialect === d.id && <CheckCircle2 className="w-4 h-4" />}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <label className="text-sm font-medium">{lang === 'ar' ? 'سرعة النطق' : 'Speech Rate'}</label>
                        <span className="text-xs font-mono bg-white/10 px-2 py-1 rounded">{speechRate}x</span>
                      </div>
                      <input 
                        type="range" 
                        min="0.5" 
                        max="2" 
                        step="0.1" 
                        value={speechRate}
                        onChange={(e) => setSpeechRate(parseFloat(e.target.value))}
                        className="w-full accent-indigo-500"
                      />
                    </div>
                  </GlassCard>
                </section>

                <section className="space-y-4">
                  <h3 className="text-sm font-bold uppercase tracking-widest opacity-40">{lang === 'ar' ? 'الملف الشخصي' : 'Profile'}</h3>
                  <GlassCard className="p-6 flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-indigo-500 to-emerald-500 flex items-center justify-center">
                      <User className="w-6 h-6" />
                    </div>
                    <div>
                      <p className="font-bold">{user.name}</p>
                      <p className="text-xs opacity-50">{user.email}</p>
                    </div>
                  </GlassCard>
                </section>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Navigation */}
      <nav className="fixed bottom-8 inset-x-6 z-50 max-w-md mx-auto">
        <GlassCard className="p-2 flex items-center justify-between bg-black/40 backdrop-blur-2xl border-white/10">
          {[
            { id: 'home', icon: Home, label: lang === 'ar' ? 'الرئيسية' : 'Home' },
            { id: 'camera', icon: Camera, label: lang === 'ar' ? 'الكاميرا' : 'Camera' },
            { id: 'history', icon: History, label: lang === 'ar' ? 'السجل' : 'History' },
            { id: 'settings', icon: Settings, label: lang === 'ar' ? 'الإعدادات' : 'Settings' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={cn(
                "flex flex-col items-center gap-1 px-4 py-2 rounded-2xl transition-all",
                activeTab === tab.id ? "bg-white/10 text-indigo-400" : "opacity-40 hover:opacity-100"
              )}
            >
              <tab.icon className="w-5 h-5" />
              <span className="text-[10px] font-bold uppercase tracking-tighter">{tab.label}</span>
            </button>
          ))}
        </GlassCard>
      </nav>
    </div>
  );
}

function Onboarding({ onComplete, isRTL }: { onComplete: (u: UserProfile) => void; isRTL: boolean }) {
  const [step, setStep] = useState(0);
  const [formData, setFormData] = useState<UserProfile>({
    name: '',
    age: '',
    email: '',
    phone: ''
  });

  const steps = [
    { 
      title: isRTL ? 'مرحباً بك في EsharaTalk' : 'Welcome to EsharaTalk',
      desc: isRTL ? 'تطبيقك الذكي لترجمة لغة الإشارة' : 'Your smart sign language translation app',
      icon: Languages
    },
    { 
      title: isRTL ? 'من أنت؟' : 'Who are you?',
      desc: isRTL ? 'أخبرنا قليلاً عن نفسك' : 'Tell us a bit about yourself',
      icon: User
    }
  ];

  return (
    <div className={cn("min-h-screen text-white flex items-center justify-center p-6", isRTL ? "rtl" : "ltr")}>
      <AnimatedBackground />
      
      <AnimatePresence mode="wait">
        <motion.div 
          key={step}
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 1.1 }}
          className="w-full max-w-md"
        >
          <GlassCard className="p-8 space-y-8">
            <div className="text-center space-y-4">
              <div className="w-20 h-20 bg-gradient-to-br from-indigo-500 to-emerald-500 rounded-3xl flex items-center justify-center mx-auto shadow-2xl shadow-indigo-500/20">
                {React.createElement(steps[step].icon, { className: "w-10 h-10" })}
              </div>
              <h2 className="text-3xl font-bold tracking-tight">{steps[step].title}</h2>
              <p className="opacity-60">{steps[step].desc}</p>
            </div>

            {step === 0 ? (
              <div className="space-y-4 pt-4">
                <div className="flex flex-col gap-3">
                  <div className="flex items-center gap-3 p-4 bg-white/5 rounded-2xl border border-white/10">
                    <div className="w-8 h-8 rounded-full bg-emerald-500/20 flex items-center justify-center">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    </div>
                    <p className="text-sm font-medium">{isRTL ? 'ترجمة فورية بـ 50 إشارة' : 'Instant translation of 50 signs'}</p>
                  </div>
                  <div className="flex items-center gap-3 p-4 bg-white/5 rounded-2xl border border-white/10">
                    <div className="w-8 h-8 rounded-full bg-indigo-500/20 flex items-center justify-center">
                      <Mic className="w-4 h-4 text-indigo-400" />
                    </div>
                    <p className="text-sm font-medium">{isRTL ? 'نطق صوتي بلهجات متعددة' : 'Voice output in multiple dialects'}</p>
                  </div>
                </div>
                <button 
                  onClick={() => setStep(1)}
                  className="w-full bg-indigo-600 hover:bg-indigo-500 py-4 rounded-2xl font-bold transition-all flex items-center justify-center gap-2 group"
                >
                  {isRTL ? 'ابدأ' : 'Get Started'}
                  <ArrowRight className={cn("w-5 h-5 transition-transform", isRTL ? "rotate-180 group-hover:-translate-x-1" : "group-hover:translate-x-1")} />
                </button>
              </div>
            ) : (
              <form 
                onSubmit={(e) => {
                  e.preventDefault();
                  onComplete(formData);
                }}
                className="space-y-4"
              >
                <input 
                  required
                  placeholder={isRTL ? 'الاسم' : 'Full Name'}
                  value={formData.name}
                  onChange={e => setFormData({...formData, name: e.target.value})}
                  className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-4 outline-none focus:border-indigo-500 transition-colors"
                />
                <div className="grid grid-cols-2 gap-4">
                  <input 
                    required
                    type="number"
                    placeholder={isRTL ? 'العمر' : 'Age'}
                    value={formData.age}
                    onChange={e => setFormData({...formData, age: e.target.value})}
                    className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-4 outline-none focus:border-indigo-500 transition-colors"
                  />
                  <input 
                    required
                    placeholder={isRTL ? 'الهاتف' : 'Phone'}
                    value={formData.phone}
                    onChange={e => setFormData({...formData, phone: e.target.value})}
                    className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-4 outline-none focus:border-indigo-500 transition-colors"
                  />
                </div>
                <input 
                  required
                  type="email"
                  placeholder={isRTL ? 'البريد الإلكتروني' : 'Email Address'}
                  value={formData.email}
                  onChange={e => setFormData({...formData, email: e.target.value})}
                  className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-4 outline-none focus:border-indigo-500 transition-colors"
                />
                <button 
                  type="submit"
                  className="w-full bg-emerald-600 hover:bg-emerald-500 py-4 rounded-2xl font-bold transition-all shadow-xl shadow-emerald-500/20"
                >
                  {isRTL ? 'إتمام التسجيل' : 'Complete Registration'}
                </button>
              </form>
            )}
          </GlassCard>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
